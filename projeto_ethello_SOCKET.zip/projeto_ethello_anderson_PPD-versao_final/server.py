import socket
import threading
import pickle

"""
configurações do servidor
"""
HOST = '127.0.0.1'  #aqui é o IP do servidor
PORT = 65432        #porta para conexão

"""
constantes do jogo
"""
VAZIO, PRETO, BRANCO = 0, 1, 2
DIRECOES = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]

"""
inicialização do tabuleiro
"""
tabuleiro = [[VAZIO] * 8 for _ in range(8)]
tabuleiro[3][3], tabuleiro[4][4] = BRANCO, BRANCO
tabuleiro[3][4], tabuleiro[4][3] = PRETO, PRETO
turno_atual = PRETO

"""
lista de clientes e cores dos jogadores
"""
clientes = []
cores = [PRETO, BRANCO]

"""
alternar o turno
"""
def alternar_turno():
    global turno_atual
    turno_atual = PRETO if turno_atual == BRANCO else BRANCO

"""
verificar se uma jogada é válida
"""
def jogada_valida(tabuleiro, linha, coluna, cor):
    if tabuleiro[linha][coluna] != VAZIO:
        return False

    outra_cor = BRANCO if cor == PRETO else PRETO
    valida = False

    for dx, dy in DIRECOES:
        x, y = linha + dx, coluna + dy
        encontrou_oponente = False

        while 0 <= x < 8 and 0 <= y < 8 and tabuleiro[x][y] == outra_cor:
            encontrou_oponente = True
            x += dx
            y += dy

        if encontrou_oponente and 0 <= x < 8 and 0 <= y < 8 and tabuleiro[x][y] == cor:
            valida = True
            break

    return valida

"""
aplicar jogada e inverter as peças
"""
def aplicar_jogada(tabuleiro, linha, coluna, cor):
    if not jogada_valida(tabuleiro, linha, coluna, cor):
        return False

    tabuleiro[linha][coluna] = cor
    outra_cor = BRANCO if cor == PRETO else PRETO
    pecas_invertidas = []

    for dx, dy in DIRECOES:
        x, y = linha + dx, coluna + dy
        caminho_para_inverter = []

        while 0 <= x < 8 and 0 <= y < 8 and tabuleiro[x][y] == outra_cor:
            caminho_para_inverter.append((x, y))
            x += dx
            y += dy

        if 0 <= x < 8 and 0 <= y < 8 and tabuleiro[x][y] == cor:
            for cx, cy in caminho_para_inverter:
                tabuleiro[cx][cy] = cor
                pecas_invertidas.append((cx, cy))

    """
    exibir feedback da jogada no servidor
    """
    print(f"Jogador {'Preto' if cor == PRETO else 'Branco'} jogou na posição ({linha}, {coluna})")
    if pecas_invertidas:
        print(f"Peças invertidas: {pecas_invertidas}")

    alternar_turno()  #alternar o turno após a jogada
    verificar_fim_jogo()  #ver se o jogo deve terminar
    return True

"""
verifica o término do jogo
"""
def verificar_fim_jogo():
    global turno_atual

    """
    contar peças no tabuleiro
    """
    pecas_pretas = sum(linha.count(PRETO) for linha in tabuleiro)
    pecas_brancas = sum(linha.count(BRANCO) for linha in tabuleiro)
    espacos_vazios = sum(linha.count(VAZIO) for linha in tabuleiro)

    """
    verificar movimentos possíveis para os dois jogadores
    """
    preto_pode_jogar = any(jogada_valida(tabuleiro, r, c, PRETO) for r in range(8) for c in range(8))
    branco_pode_jogar = any(jogada_valida(tabuleiro, r, c, BRANCO) for r in range(8) for c in range(8))

    """
    caso nenhum jogador possa jogar, o jogo termina
    """
    if not preto_pode_jogar and not branco_pode_jogar:
        enviar_dados_para_todos((tabuleiro, turno_atual))
        if pecas_pretas > pecas_brancas:
            enviar_dados_para_todos(("fim_jogo", "Preto venceu!"))
        elif pecas_brancas > pecas_pretas:
            enviar_dados_para_todos(("fim_jogo", "Branco venceu!"))
        else:
            enviar_dados_para_todos(("fim_jogo", "Empate!"))
        return True

    """
    caso o jogador atual não possa jogar, passar o turno
    """
    if not any(jogada_valida(tabuleiro, r, c, turno_atual) for r in range(8) for c in range(8)):
        print(f"Jogador {'Preto' if turno_atual == PRETO else 'Branco'} não pode jogar. Turno passado.")
        alternar_turno()

    return False

"""
função para manipular com os clientes
"""
def lidar_com_cliente(conexao, cor_jogador):
    global tabuleiro
    try:
        conexao.sendall(pickle.dumps((tabuleiro, cor_jogador, turno_atual)))
        while True:
            dados = conexao.recv(1024)
            if not dados:
                break
            jogada = pickle.loads(dados)
            linha, coluna = jogada

            if turno_atual == cor_jogador and aplicar_jogada(tabuleiro, linha, coluna, cor_jogador):
                enviar_dados_para_todos((tabuleiro, turno_atual))
    except (ConnectionResetError, ConnectionAbortedError):
        print(f"Jogador {'Preto' if cor_jogador == PRETO else 'Branco'} desconectado.")
        notificar_desconexao(cor_jogador)
    finally:
        conexao.close()

"""
notifica desconexão e declarar vencedor
"""
def notificar_desconexao(cor_desconectada):
    cor_restante = BRANCO if cor_desconectada == PRETO else PRETO
    enviar_dados_para_todos(("fim_jogo", f"Jogador {'Preto' if cor_restante == PRETO else 'Branco'} venceu por desconexão do oponente."))

"""
envia dados para todos os clientes
"""
def enviar_dados_para_todos(dados):
    for conexao in clientes:
        try:
            conexao.sendall(pickle.dumps(dados))
        except:
            pass

"""
inicializando o servidor
"""
servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
servidor.bind((HOST, PORT))
servidor.listen(2)
print("Servidor iniciado e aguardando conexões...")

"""
aceitar conexões de dois clientes
"""
while len(clientes) < 2:
    conexao, endereco = servidor.accept()
    cor_jogador = cores[len(clientes)]
    clientes.append(conexao)
    print(f"Cliente conectado: {endereco}, cor: {'Preto' if cor_jogador == PRETO else 'Branco'}")
    threading.Thread(target=lidar_com_cliente, args=(conexao, cor_jogador)).start()
