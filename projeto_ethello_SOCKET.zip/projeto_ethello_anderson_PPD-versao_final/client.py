import socket
import pickle
import tkinter as tk
from tkinter import messagebox
import threading

"""
configurações do cliente e conexão com o servidor
"""
HOST = '127.0.0.1'  #IP do servidor
PORT = 65432        #porta de conexão

"""
conecta ao servidor utilizando socket TCP
"""
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

"""
variáveis globais para armazenar o estado do jogo
"""
tabuleiro = None
cor_jogador = None
turno_atual = None
botoes = []
pontuacao_preto = 0
pontuacao_branco = 0
rotulo_pontuacao = None  #para mostrar a pontuação dos jogadores
rotulo_turno = None  #para mostrar a mensagem do turno atual

"""
definições de valores do tabuleiro e estilos visuais
"""
VAZIO, PRETO, BRANCO = 0, 1, 2
CORES = {VAZIO: "#D2B48C", PRETO: "#333333", BRANCO: "#F5F5F5"} 
ESTILO_BOTOES = {
    VAZIO: {"bg": "#D2B48C", "fg": "white", "highlightbackground": "#8B4513", "relief": "ridge"},
    PRETO: {"bg": "#333333", "fg": "white", "highlightbackground": "#000000", "relief": "solid"},
    BRANCO: {"bg": "#F5F5F5", "fg": "black", "highlightbackground": "#D3D3D3", "relief": "solid"},
}

"""
criação e configuração da janela principal
"""
janela = tk.Tk()
janela.title("Othello Game")
janela.configure(bg="#8B4513")  #tema de madeira

"""
aplica cores quentes no texto
"""
def gradiente_cores_quentes(widget_texto, texto):
    cores = ["#FF4500", "#FF6347", "#FFA500"]  #cores para parecer com jogo
    for idx, char in enumerate(texto):
        widget_texto.insert(tk.END, char)
        widget_texto.tag_add(f"cor{idx}", f"1.{idx}", f"1.{idx + 1}")
        widget_texto.tag_config(f"cor{idx}", foreground=cores[idx % len(cores)])

"""
atualiza a aparência dos botões com base no estado atual do tabuleiro
"""
def renderizar_tabuleiro():
    global tabuleiro
    if tabuleiro is None:
        return  #ver que o tabuleiro foi definido antes de renderizar
    for i in range(8):
        for j in range(8):
            botao = botoes[i][j]
            estilo = ESTILO_BOTOES[tabuleiro[i][j]]
            botao.config(
                bg=estilo["bg"],
                fg=estilo["fg"],
                activebackground=estilo["bg"],
                highlightbackground=estilo["highlightbackground"],
                relief=estilo["relief"],
            )
    atualizar_pontuacao()  #atualiza a pontuação
    atualizar_mensagem_turno()  #mensagem do turno atual

"""
envia a jogada do jogador ao servidor
"""
def enviar_jogada(linha, coluna):
    global cor_jogador, turno_atual
    if cor_jogador != turno_atual:
        messagebox.showinfo("Aguarde", "Turno atual do oponente.")
        return

    client.sendall(pickle.dumps((linha, coluna)))

"""
cria os botões do tabuleiro do jogo
"""
def criar_tabuleiro():
    global botoes
    for i in range(8):
        linha = []
        for j in range(8):
            botao = tk.Button(
                janela, 
                width=5, 
                height=2, 
                font=('Arial', 12, 'bold'),
                command=lambda r=i, c=j: enviar_jogada(r, c),
                bd=2, 
                relief="ridge", 
                highlightbackground="#8B4513",  #borda dos botões
                highlightcolor="#654321",  #cor de destaque ao passar o mouse
            )
            botao.grid(row=i + 2, column=j + 1, padx=3, pady=3)  #espaçamento entre os botões
            linha.append(botao)
        botoes.append(linha)


"""
adiciona título inicial com animação
"""
def animar_titulo(titulo, rotulo, indice=0):
    if indice < len(titulo):
        rotulo.config(text=titulo[:indice + 1])  #adiciona uma letra por vez
        janela.after(100, animar_titulo, titulo, rotulo, indice + 1)
    else:
        #após a animação, muda a cor do texto periodicamente para destacar
        alternar_cor_titulo(rotulo)

def alternar_cor_titulo(rotulo):
    cores = ["#FF4500", "#FFA500", "#FF6347"]
    cor_atual = rotulo.cget("fg")
    proxima_cor = cores[(cores.index(cor_atual) + 1) % len(cores)]
    rotulo.config(fg=proxima_cor)
    janela.after(500, alternar_cor_titulo, rotulo)

"""
cria o rótulo de título inicial
"""
def criar_titulo_animado():
    titulo = "OTHELLO GAME"
    rotulo_titulo = tk.Label(
        janela, 
        text="", 
        font=("Impact", 24, "bold"), 
        bg="#8B4513", 
        fg="#FF4500"
    )
    rotulo_titulo.grid(row=0, column=1, columnspan=8, pady=10)   #centraliza o título no topo
    animar_titulo(titulo, rotulo_titulo)

"""
calcula e exibe a pontuação atual dos jogadores
"""
def atualizar_pontuacao():
    global tabuleiro, pontuacao_preto, pontuacao_branco, rotulo_pontuacao
    pontuacao_preto = sum(linha.count(PRETO) for linha in tabuleiro)
    pontuacao_branco = sum(linha.count(BRANCO) for linha in tabuleiro)
    rotulo_pontuacao.config(text=f"Pontos:\nPreto: {pontuacao_preto}\nBranco: {pontuacao_branco}")

"""
cria o rótulo de pontuação na interface
"""
def criar_rotulo_pontuacao():
    global rotulo_pontuacao
    rotulo_pontuacao = tk.Label(janela, text="Pontos:\nPreto: 0\nBranco: 0", font=('Impact', 14, 'bold'), bg="#654321", fg="#FFA500", justify=tk.LEFT)
    rotulo_pontuacao.grid(row=1, column=0, rowspan=8, padx=10)

"""
cria o rótulo que indica o turno atual
"""
def criar_rotulo_turno():
    global rotulo_turno
    rotulo_turno = tk.Label(janela, text="", font=('Impact', 16, 'bold'), bg="#8B4513", fg="#FF6347")
    rotulo_turno.grid(row=10, column=1, columnspan=8, pady=5)

"""
atualiza a mensagem exibida sobre o turno atual
"""
def atualizar_mensagem_turno():
    global rotulo_turno, cor_jogador, turno_atual
    if cor_jogador == turno_atual:
        rotulo_turno.config(text="É a sua vez!", fg="#228B22")  #verde se for a vez
    else:
        rotulo_turno.config(text="Aguarde o oponente...", fg="#FF4500")  #vermelho se não for a vez

"""
função para exibir o nome do jogador
"""
def exibir_nome_jogador():
    global cor_jogador
    nome_jogador = "Jogador 1 (Preto)" if cor_jogador == PRETO else "Jogador 2 (Branco)"
    
    """
    cor para cada jogador
    """
    cor_fundo = "#D2B48C" if cor_jogador == PRETO else "#654321"
    cor_texto = "#333333" if cor_jogador == PRETO else "#FFFFFF" 
    
    """
    criando o rótulo estilizado
    """
    rotulo_nome = tk.Label(
        janela, 
        text=nome_jogador, 
        font=('Impact', 16, 'bold'), 
        bg=cor_fundo, 
        fg=cor_texto, 
        bd=2, 
        relief="ridge"
    )
    rotulo_nome.grid(row=1, column=1, columnspan=8, pady=5)


"""
receber dados do servidor e atualizar o tabuleiro
"""
def receber_dados():
    global tabuleiro, turno_atual, cor_jogador
    """
    recebe dados iniciais do servidor
    """
    dados_iniciais = pickle.loads(client.recv(4096))
    tabuleiro, cor_jogador, turno_atual = dados_iniciais
    renderizar_tabuleiro()  #renderiza o tabuleiro inicial após receber dados
    exibir_nome_jogador()

    while True:
        dados = client.recv(4096)
        dados_recebidos = pickle.loads(dados)

        if dados_recebidos[0] == "fim_jogo":
            messagebox.showinfo("Jogo Encerrado", dados_recebidos[1])
            client.close()
            janela.quit()
            break
        else:
            tabuleiro, turno_atual = dados_recebidos
            renderizar_tabuleiro()

"""
criar e configurar o tabuleiro
"""
criar_tabuleiro()

"""
criar o rótulo de pontuação
"""
criar_rotulo_pontuacao()

"""
criar o rótulo de turno
"""
criar_rotulo_turno()


"""
chama a função para criar o título animado
"""
criar_titulo_animado()

"""
iniciar thread para receber dados do servidor
"""
threading.Thread(target=receber_dados, daemon=True).start()

"""
iniciar a interface
"""
janela.mainloop()
